
-- Preparando o shape de simuid
-- 1) Simplificando topologia.
select count(*) from treinamento.simu_brazil_disjoint_units;
select * from treinamento.simu_brazil_disjoint_units limit 100;

drop table if exists treinamento.simplified_globiom_simu_brasil;
create table treinamento.simplified_globiom_simu_brasil as
		select id, simuid, (st_dump(geom)).geom as the_geom
        from treinamento.simu_brazil_disjoint_units;

select count(*) from treinamento.simplified_globiom_simu_brasil;

-- 2) Verificando (e corrigindo) possíveis erros

select sum(st_area(the_geom)) from treinamento.simplified_globiom_simu_brasil;
select * from treinamento.simplified_globiom_simu_brasil where ST_IsValid(the_geom) = false;

update treinamento.simplified_globiom_simu_brasil
	SET the_geom = ST_Buffer(ST_SimplifyPreserveTopology(the_geom, 0.0001), 0) 
	where ST_IsValid(the_geom) = false;

select sum(st_area(the_geom)) from treinamento.simplified_globiom_simu_brasil;
select * from treinamento.simplified_globiom_simu_brasil where ST_IsValid(the_geom) = false;

-- 3)Criando índice espacial.
CREATE INDEX INDEX_simplified_globiom_simu_brasil on treinamento.simplified_globiom_simu_brasil 
		using gist(the_geom);
ANALYZE treinamento.simplified_globiom_simu_brasil;
cluster treinamento.simplified_globiom_simu_brasil using INDEX_simplified_globiom_simu_brasil;

select * from treinamento.simplified_globiom_simu_brasil limit 100;

-- Calcula o número de pixels que contém determinada categoria, por SimuID. 
drop table if exists prodescerrado.share_prodes_cerrado;
create table prodescerrado.share_prodes_cerrado as
select a.rid, (st_valuecount(a.rast)).value as categ_value, 
	(st_valuecount(a.rast)).count as numpixels, 
		       b.id as id_simu, b.simuid
		from prodescerrado.prodes_cerrado_adapted as a,
		     treinamento.simplified_globiom_simu_brasil as b
		where ST_Intersects(a.rast, b.the_geom)
		order by b.simuid, a.rid;
        
select * from prodescerrado.share_prodes_cerrado limit 10;

drop table if exists prodescerrado.share_classes_prodes_simu;
create table prodescerrado.share_classes_prodes_simu as
select a.*, b.npixels_simu, c.cr, c.alt, c.slope, c.soil,
	c.aezclass, c.simuarea, (cast(a.numpixels as double precision) / 
				cast(b.npixels_simu as double precision)) as share_pixels,
	 ((cast(a.numpixels as double precision) / 
				cast(b.npixels_simu as double precision))* cast(c.simuarea as double precision)) as share_area			
	from prodescerrado.share_prodes_cerrado as a
        left join (select t1.simuid, sum(t1.numpixels) as npixels_simu  
		from prodescerrado.share_prodes_cerrado as t1
		group by t1.simuid
		order by t1.simuid) as b
	on a.simuid = b.simuid
      --order by a.simuid, a.categ_value
      left join globiom.globiom_simu_brazil_basic_data as c
      on a.simuid = c.simuid;

select count(*) from prodescerrado.share_classes_prodes_simu;
											
drop table if exists prodescerrado.sharearea_final_prodes_cerrado;
create table prodescerrado.sharearea_final_prodes_cerrado as
select simuid, categ_value, sum(share_area) as area_category
      from prodescerrado.share_classes_prodes_simu
      group by categ_value, simuid
      order by simuid;

COPY (select *
	from prodescerrado.sharearea_final_prodes_cerrado
	order by simuid) 
	TO 'D:/fable/csv/prodes_cerrado_simuid.csv' DELIMITER ',' CSV HEADER;

