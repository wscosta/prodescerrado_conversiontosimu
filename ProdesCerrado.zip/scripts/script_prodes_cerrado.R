library(plyr)
library(devtools)
library(reshape2)
library(data.table)

rm(list=ls());

#dados de entrada
dados_prodes_cerrado <- read.csv(file="D:\\fable\\csv\\prodes_cerrado_simuid.csv", header = T, stringsAsFactors = F);
classes_prodes <- read.csv(file="D:\\fable\\csv\\classes_prodes_cerrado.csv", header = T, stringsAsFactors = F);


#Retirando dados NA
dados_prodes_cerrado[is.na(dados_prodes_cerrado)] <- 0
dados_prodes_cerrado <- subset(dados_prodes_cerrado, categ_value != 1)


#Juntando o dado do PRODES Cerrado com as suas respectivas classes
dados_prodes_cerrado_merge <- merge(x= dados_prodes_cerrado, y=classes_prodes, by.x="categ_value", by.y="valor_pixel", all.x = T, all.y = T)
dados_prodes_cerrado_merge <- na.omit(dados_prodes_cerrado_merge)
dados_prodes_cerrado_merge[is.na(dados_prodes_cerrado_merge)] <- 0


prodes_cerrado_simu <- ddply(dados_prodes_cerrado_merge, .(simuid, classe_prodes_cerrado), summarize, sum_area = sum(area_category))
prodes_cerrado_simu <- na.omit(prodes_cerrado_simu)
prodes_cerrado_simu <- subset(prodes_cerrado_simu, simuid != 0)

#transformando o dado em data.table para manipulacoes
setDT(prodes_cerrado_simu)

#dividindo os valores bi-anuais por 2
prodes_cerrado_simu[classe_prodes_cerrado == 'd2002', sum_area := sum_area/2]
prodes_cerrado_simu[classe_prodes_cerrado == 'd2004', sum_area := sum_area/2]
prodes_cerrado_simu[classe_prodes_cerrado == 'd2006', sum_area := sum_area/2]
prodes_cerrado_simu[classe_prodes_cerrado == 'd2008', sum_area := sum_area/2]
prodes_cerrado_simu[classe_prodes_cerrado == 'd2010', sum_area := sum_area/2]
prodes_cerrado_simu[classe_prodes_cerrado == 'd2012', sum_area := sum_area/2]


#gerando as classes para os anos faltantes 
prodes_cerrado_simu = rbind(prodes_cerrado_simu, prodes_cerrado_simu[classe_prodes_cerrado == 'd2002'][,'classe_prodes_cerrado' := '2001'])
prodes_cerrado_simu = rbind(prodes_cerrado_simu, prodes_cerrado_simu[classe_prodes_cerrado == 'd2004'][,'classe_prodes_cerrado' := '2003'])
prodes_cerrado_simu = rbind(prodes_cerrado_simu, prodes_cerrado_simu[classe_prodes_cerrado == 'd2006'][,'classe_prodes_cerrado' := '2005'])
prodes_cerrado_simu = rbind(prodes_cerrado_simu, prodes_cerrado_simu[classe_prodes_cerrado == 'd2008'][,'classe_prodes_cerrado' := '2007'])
prodes_cerrado_simu = rbind(prodes_cerrado_simu, prodes_cerrado_simu[classe_prodes_cerrado == 'd2010'][,'classe_prodes_cerrado' := '2009'])
prodes_cerrado_simu = rbind(prodes_cerrado_simu, prodes_cerrado_simu[classe_prodes_cerrado == 'd2012'][,'classe_prodes_cerrado' := '2011'])

#renomeando as classes
prodes_cerrado_simu[classe_prodes_cerrado == 'd2000', classe_prodes_cerrado := '2000']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2002', classe_prodes_cerrado := '2002']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2004', classe_prodes_cerrado := '2004']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2006', classe_prodes_cerrado := '2006']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2008', classe_prodes_cerrado := '2008']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2010', classe_prodes_cerrado := '2010']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2012', classe_prodes_cerrado := '2012']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2013', classe_prodes_cerrado := '2013']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2014', classe_prodes_cerrado := '2014']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2015', classe_prodes_cerrado := '2015']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2016', classe_prodes_cerrado := '2016']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2017', classe_prodes_cerrado := '2017']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2018', classe_prodes_cerrado := '2018']
prodes_cerrado_simu[classe_prodes_cerrado == 'd2019', classe_prodes_cerrado := '2019']

#removando as classes irrelevantes
prodes_cerrado_simu <- subset(prodes_cerrado_simu, classe_prodes_cerrado != "hidrografia" & classe_prodes_cerrado != "residuo2018")

#ordenando o csv por ano e em seguida, por simuid
prodes_cerrado_simu_sorted <- prodes_cerrado_simu[order(prodes_cerrado_simu$simuid, prodes_cerrado_simu$classe_prodes_cerrado),]

#salvando o csv
write.table(prodes_cerrado_simu_sorted, file=paste("D:\\fable\\csv\\", "prodes_cerrado_final.csv", sep=""), row.names = F, col.names = F, sep=",")

